/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Appliance;

import java.util.ArrayList;

/**
 *
 * @author d00267317
 */
public class HouseTest {
    public static void main (String []args)
    {
        //Set House 1
        House h1 = new House ();
        h1.setName  ("Beginner House");
        h1.setLocation ("Suburbs");
        h1.setEnergy (25);
        h1.setRooms (4);
        
        //Setting appliances
        Appliance a1 = new Appliance ("Stove","Kitchen",true,3.5,0.90);
        Appliance a2 = new Appliance ("Water heater","Hot Press",false,4,1.47);
        h1.addAppliance (a1);
        h1.addAppliance (a2);
        System.out.println (h1+"\n");
    }
}
